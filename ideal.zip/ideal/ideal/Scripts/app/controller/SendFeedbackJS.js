﻿$(document).ready(function () {
    $("#categoryName").html("Câu hỏi liên quan nhân sự / Tiền lương");

    $("#listCategory").on('change', function () {
        var category = $("#listCategory option:selected").html().toLowerCase();

        if (category == "liên quan nhân sự") {
            category = "nhân sự";
        }
        if (category == "Câu hỏi khác") {
            category = "nhân sự khác";
        }

        var str = "Câu hỏi liên quan " + category;

        $("#categoryName").html(str);
    });

    $("#subCategory").on('change', function () {
        var subCategory = $("#subCategory option:selected").html();
        var category = $("#listCategory option:selected").html().toLowerCase();

        if (category == "liên quan nhân sự") {
            category = "nhân sự";
        }
        if (category === "Câu hỏi khác") {
            category = "nhân sự khác";
        }

        var str = "Câu hỏi liên quan " + category + ' / ' +subCategory;

        $("#categoryName").html(str);
    });


    $("#btnSendEmail").click(function () {
        var category = $("#listCategory").val();
        var subCategory = $("#subCategory").val();
        var content = $("#txtFeedback").val();
        $.ajax({
            type: "GET",
            data: {
                category: category,
                subCategory: subCategory,
                content: content
            },
            url: "/QA/Feedback",
            dataType: "json",
            success: function (data) {
                alert("Cảm ơn bạn đã gởi câu hỏi cho chúng tôi.")
                $("#txtFeedback").val("");
            },
            error: function (xhr) {
                alert("Gởi không thành công.")
            }
        });
    });
});