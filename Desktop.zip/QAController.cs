﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ideal.ModelView;
using ideal.Repositories;
using System.Net.Mail;
using System.Net;
using ideal.Models;

namespace ideal.Controllers
{
    public class QAController : Controller
    {

        private QuestionRepository _re = new QuestionRepository();
        //    GET: QA
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CauHoi()
        {
            return View();
        }

        public JsonResult GetData(string cate)
        {
            var data = _re.ListQuestion(cate);

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAnswer(int id)
        {
            var data = _re.GetAnswerById(id);

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SendFeedback(string content, int category)
        {
            try
            {
                var createdBy = (int)Session["UserId"];
                QuestionRepository _reQuestion = new QuestionRepository();
                _reQuestion.Insert(content, category, createdBy);

            }
            catch (Exception ex)
            {
                var Err = ex.InnerException;
            }
            return View("Index");
        }

        public ActionResult GetCategory()
        {
            IdealDbEntities _db = new IdealDbEntities();

            return Json(_db.tb_Categories.Select(x => new
            {
                Id = x.Id,
                Category = x.Category
            }).ToList(), JsonRequestBehavior.AllowGet);
        }

        private void SendEmail(string content)
        {
            var sender = new MailAddress("ryo.devil@gmail.com", "Mr Kaplan");
            var receiver = new MailAddress("duyitdotcom@gmail.com", "Bellamy");
            var password = "abc";
            var body = content;
            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(sender.Address, password)
            };

            using (var mess = new MailMessage(sender, receiver)
            {
                Subject = "Góp ý",
                Body = body
            })
            {
                smtp.Send(mess);
            }
        }

    }
}