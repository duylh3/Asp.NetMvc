﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ideal.ModelView;
using ideal.Repositories;
using System.Net.Mail;
using System.Net;
using ideal.Models;
using System.Configuration;
using System.Text;

namespace ideal.Controllers
{
    public class QAController : Controller
    {

        private QuestionRepository _re = new QuestionRepository();
        //    GET: QA
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CauHoi()
        {
            return View();
        }

        public JsonResult GetData(string cate)
        {
            var data = _re.ListQuestion(cate);

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAnswer(int id)
        {
            var data = _re.GetAnswerById(id);

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SendFeedback(string content, int category)
        {
            try
            {
                SendEmailG(content);
                var createdBy = (int)Session["UserId"];
                QuestionRepository _reQuestion = new QuestionRepository();
                _reQuestion.Insert(content, category, createdBy);

            }
            catch (Exception ex)
            {
                var Err = ex.InnerException;
            }
            return View("Index");
        }

        public ActionResult GetCategory()
        {
            IdealDbEntities _db = new IdealDbEntities();

            return Json(_db.tb_Categories.Select(x => new
            {
                Id = x.Id,
                Category = x.Category
            }).ToList(), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult History()
        {
            return View();
        }

        public ActionResult GetHistory()
        {
            var data = _re.ListHistory();
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public static bool SendEmailG(string body)
        {
            try
            {
                AppSettingsReader app = new AppSettingsReader();
                string from = (string)app.GetValue("FromEmailAddress", typeof(String));
                string pass = (string)app.GetValue("FromEmailPassword", typeof(String));
                string hostName = (string)app.GetValue("SMTPHost", typeof(String));
                string nameDisplay = (string)app.GetValue("FromEmailDisplayName", typeof(String));
                int port = (int)app.GetValue("SMTPPort", typeof(int));
                string To = "duylh@posco.net";
                string subject = "Test mail gop y";

                MailMessage mail = new MailMessage();
                SmtpClient smtp = new SmtpClient(hostName);
                mail.From = new MailAddress(from, nameDisplay);
                mail.To.Add(To);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;
                mail.BodyEncoding = UTF8Encoding.UTF8;
                smtp.Credentials = new System.Net.NetworkCredential(from, pass);
                smtp.EnableSsl = false;
                smtp.Send(mail);
                return true;
            }catch(Exception ex)
            {
                var Err = ex.InnerException + ex.Message;
                return false;
            }
        }
    }
}